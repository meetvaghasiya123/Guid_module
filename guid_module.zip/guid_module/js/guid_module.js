(function ($, Drupal) {
  Drupal.behaviors.guidModuleBehavior = {
    attach: function (context, settings) {
      // Check if GUID exists in settings and if the page is NOT part of the admin interface.
      if (
        settings.guid &&
        !$('.guid-processed').length &&
        !$('body').hasClass('path-admin')
      ) {
        console.log("GUID loaded: " + settings.guid);

        // Inject GUID into the body element for the frontend.
        $('body').append('<div class="guid-processed" style="display:none;">' + settings.guid + '</div>');
      }
    }
  };
})(jQuery, Drupal);


// (function ($, Drupal) {
//   Drupal.behaviors.guidModuleBehavior = {
//     attach: function (context, settings) {
//       // Ensure the GUID is processed only once.
//       if (settings.guid && !$('.guid-processed').length) {
//         console.log("GUID loaded: " + settings.guid);
//         // Example: Inject GUID into a specific element.
//         $('body').append('<div class="guid-processed" style="display:none;">' + settings.guid + '</div>');
//       }
//     }
//   };
// })(jQuery, Drupal);





// (function ($, Drupal) {
//   Drupal.behaviors.guidModuleBehavior = {
//     attach: function (context, settings) {
//       // Ensure the GUID is processed only once.
//       if (settings.guid && !$('.guid-processed').length) {
//         console.log("GUID loaded: " + settings.guid);
//         // Example: Inject GUID into a specific element.
//         $('body').append('<div class="guid-processed" style="display:none;">' + settings.guid + '</div>');
//       }
//     }
//   };
// })(jQuery, Drupal);









// (function ($) {
//   Drupal.behaviors.guidModuleBehavior = {
//     attach: function (context, settings) {
//       // Check if the GUID is set in drupalSettings
//       if (typeof settings.guid !== 'undefined') {
//         // If GUID is found, use it
//         var guid = settings.guid;
//         console.log("GUID on this page: " + guid);

//         // You can now use the GUID for your purposes, e.g., inject it into elements
//       }
//       else {
//         console.error("GUID not found in drupalSettings.");
//       }
//     }
//   };
// })(jQuery);






// (function ($, Drupal) {
//   Drupal.behaviors.guidModule = {
//     attach: function (context, settings) {
//       if (!Drupal.settings.guid) {
//         return;
//       }
//       // Inject the GUID into the front-end pages.
//       var guid = Drupal.settings.guid;
//       console.log('GUID: ', guid); // Example: you can use this GUID however you want on the front-end
//     }
//   };
// })(jQuery, Drupal);
