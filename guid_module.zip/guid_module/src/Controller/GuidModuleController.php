<?php

namespace Drupal\guid_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class GuidModuleController.
 *
 * @package Drupal\guid_module\Controller
 */
class GuidModuleController extends ControllerBase {

  /**
   * The form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilderInterface
   */
  protected $formBuilder;

  /**
   * Constructs a new GuidModuleController object.
   *
   * @param \Drupal\Core\Form\FormBuilderInterface $form_builder
   *   The form builder service.
   */
  public function __construct(FormBuilderInterface $form_builder) {
    $this->formBuilder = $form_builder;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('form_builder')
    );
  }

  /**
   * Settings page callback.
   *
   * @return array
   *   The page content.
   */
  public function settingsPage() {
    // Return the form for GUID settings.
    return $this->formBuilder->getForm('Drupal\guid_module\Form\GuidModuleForm');
  }
}
