<?php

namespace Drupal\guid_module\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class GuidModuleForm.
 *
 * @package Drupal\guid_module\Form
 */
class GuidModuleForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'guid_module_guid_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = \Drupal::config('guid_module.settings');
    $guid = $config->get('guid');

    $form['guid'] = [
      '#type' => 'textfield',
      '#title' => $this->t('GUID'),
      '#default_value' => $guid ? $guid : guid_module_generate_guid(),
      '#description' => $this->t('This GUID will be injected into the front-end pages.'),
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save GUID'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $guid = $form_state->getValue('guid');
    \Drupal::configFactory()->getEditable('guid_module.settings')->set('guid', $guid)->save();
  }
}
